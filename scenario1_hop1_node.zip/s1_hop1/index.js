module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

        var request = require("request"); 
        var post_data = {
            body: "Hello from hop1"
        };
        var uri =  "https://scenario1-hop2-azure-function.azurewebsites.net/api/s1_hop2";
        context.log("Path to request: " + uri);

        request.post(uri,post_data,function (error, response, body) {
            if (!error) {
                context.log("Successfully");
                context.res = {
                    body: body
                };
                context.done(); 
            }
            else{
                context.log("Error occured");
                context.res = {
                    status: 400,
                    body: error
                };
                context.done(); 
            }
        });
};