module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    if (req.query.func_code) {
        
        var https = require("http"); 
        var post_data = JSON.stringify({ "name" : "Hello from S1_hop1 function"});


        var options = {
            host: "scenario1-hop2-azure-function.azurewebsites.net",         
            path: "api/s1_hop2?code=" + req.query.func_code,
            method: "POST",
            headers : {
                "Content-Type":"application/json",
                "Content-Length": Buffer.byteLength(post_data)
              }    
        };

        var request = http.request(options, function(response) {
            var str = "";
            response.on("data", function (chunk) {
              str += chunk;
            });
      
            response.on("end", function () {
                context.res = {
                    body: str
                };          
            });          
          });
      
          request.write(post_data);
          request.end();
          request.on('error', function(e) {
            console.error(e);
            context.res = {
                status: 400,
                body: e
            };
          });
    }

    else {
        context.res = {
            status: 400,
            body: "Please pass a name on the query string or in the request body"
        };
    }
    context.done();
};