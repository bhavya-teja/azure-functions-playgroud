module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    if (req.query.func_code) {
        
        var request = require("request"); 
        var post_data = JSON.stringify({ "name" : "Hello from S1_hop1 function"});
        var uri =  "https://scenario1-hop2-azure-function.azurewebsites.net/api/s1_hop2?code=" + req.query.func_code;
        context.log("Path to request: " + uri);

        request.post(uri,post_data,function (error, response, body) {
            if (!error) {
                context.res = {
                    body: body
                  };
            }
            else{
                context.res = {
                    status: 400,
                    body: e
                };
                context.done(); 
            }
        });
    } else {
        context.res = {
            status: 400,
            body: "Please pass a name on the query string or in the request body"
        };
    }
};