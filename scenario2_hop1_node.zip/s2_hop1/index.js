module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    if (req.body.hop2_code && req.body.hop3_code && req.body.hop4_code && req.body.hop5_code) {
        
        var request = require("request"); 
        var request2 = require("request");
        var request3 = require("request");
        var post_data = JSON.stringify({ "func4_code" : req.body.func_code4});

        var answer1 = "";
        var answer2 = "";
        var answer3 = "";

        var uri1 =  "https://scenario2-hop2-azure-function.azurewebsites.net/api/s2_hop2?code=" + req.body.hop2_code;
        var uri2 =  "https://scenario2-hop3-azure-function.azurewebsites.net/api/s2_hop3?code=" + req.body.hop3_code;
        var uri3 =  "https://scenario2-hop4-azure-function.azurewebsites.net/api/s2_hop4?code=" + req.body.hop4_code;
        
        context.log("Path to request1: " + uri1);
        context.log("Path to request2: " + uri2);
        context.log("Path to request3: " + uri3);

        request.post(uri1,post_data,function (error, response, body) {
            if (!error) {
                context.log("Successfully executed the first request!");
                answer1 = body;
            }
            else{
                context.log("Error occured with first request");
                context.res = {
                    status: 400,
                    body: error
                };
                context.done(); 
            }
        });

        request2.post(uri2, post_data, function (error2, response2, body2) {
            answer2 = body2;
            if(!error2) {
                context.log("Successfully executed the second request!");
            }
        });

        request3.post(uri3, post_data, function (error3, response3, body3) {
            if(!error3) {
                context.log("Successfully executed the second request!");
                context.res = {
                    body: {
                        response1: answer1,
                        response2: answer2,
                        response3: answer3
                    }
                };
                context.done(); 
            }
        });
    } else {
        context.res = {
            status: 400,
            body: "Please pass a func_code, func_code2, func_code3, func_code4 into the body of the reques"
        };
        context.done(); 
    }
};