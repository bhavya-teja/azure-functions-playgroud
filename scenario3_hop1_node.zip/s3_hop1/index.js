module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

        var request = require("request"); 
        var request2 = require("request");
        var post_data = JSON.stringify({ "name" : "Hello from S1_hop1 function"});
        var uri =  "https://scenario3-hop2-azure-function.azurewebsites.net/api/s3_hop2";
        var uri2 =  "https://scenario3-hop3-azure-function.azurewebsites.net/api/s3_hop3";
        context.log("Path to request: " + uri);

        request.post(uri,post_data,function (error, response, body) {
            if (!error) {
                context.log("Successfully executed the first request!");

                request2.post(uri2, post_data, function (error2, response2, body2) {
                    if(!error2) {
                        context.log("Successfully executed the second request!");
                        context.res = {
                            body: {
                                response1: body,
                                response2: body2
                            }
                        };
                        context.done(); 
                    }
                })
            }
            else{
                context.log("Error occured with first request");
                context.res = {
                    status: 400,
                    body: error
                };
                context.done(); 
            }
        });
};