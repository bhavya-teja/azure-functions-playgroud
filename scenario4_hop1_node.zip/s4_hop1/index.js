module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    var req = require('request');
    var uri = "https://jsonplaceholder.typicode.com/posts";

    req(uri,function (error, response, body) {
        if(!error){
            context.res = {
                status: 200,
                body: response
            };
            context.done();
        } else {
            context.res = {
                status: 400,
                body: error
            };
            context.done();
        }
    });
};