module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    var https = require('request');
    var uri =  "https://scenario5-hop1-azure-function.azurewebsites.net/api/s5_hop1";

    https(uri,function (error, response, body) {
            if(!error && req.body.calls > 1){
                request.post(uri,
                    { calls: 0 },
                    function (error, response, body) {
                        if (!error) {
                            context.res = {
                                status: 200,
                                body: "Cyclic executed"
                            };
                            context.done();
                        }
                        else
                        {
                            context.res = {
                                status: 200,
                                body: "No cyclic action executed"
                            };
                            context.done();
                        }
                    }
                );
            }
            else {
            context.res = {
                status: 200,
                body: "No cyclic action executed"
            };
            context.done();
        }
    });
};